# RBAC Laboratory Activity — Step-by-Step Instructions

**Role-Based Access Control in Laravel** — Implementing Gates and Policies in a Laravel Inventory System

> Follow the parts in order. Every code block is ready to copy-paste. Where it says **"Replace all of"**, delete the file's entire contents and paste the block in.

---

## Requirements

- PHP 8.3+ and Composer
- Laravel 13 (created via `composer create-project`) with SQLite (zero configuration)
- The `inventory-rbac-starter` folder from `RBAC.zip`

---

## Part A — Set Up and Explore the Starter Application

### Step 1. Create the project and install Fortify

```bash
composer create-project laravel/laravel inventory-rbac
cd inventory-rbac
composer require laravel/fortify
php artisan fortify:install
```

### Step 2. Copy the starter files

Copy the **contents** of the `inventory-rbac-starter` folder into the project root, **overwriting** files when prompted. This replaces `routes/web.php`, `database/seeders/DatabaseSeeder.php`, and `app/Providers/FortifyServiceProvider.php`, and adds the controllers, models, views, migrations, and CSS.

### Step 3. Configure Fortify

Open `config/fortify.php` and change these two settings (login/logout only; registration is disabled because a new registrant would have no role):

```php
'home' => '/inventory',
```

```php
'features' => [],
```

### Step 4. Migrate, seed, and serve

```bash
php artisan migrate --seed
php artisan serve
```

### Step 5. Log in and observe the problem

Visit `http://127.0.0.1:8000`. Password for all accounts is `password`:

| Role | Email |
|---|---|
| System Administrator | admin@inventory.test |
| Receiving Clerk | clerk@inventory.test |
| Inventory Manager | manager@inventory.test |
| Inventory Supervisor | supervisor@inventory.test |
| Reports Officer | reports@inventory.test |

**The problem:** every account can add, edit, remove, view, and print. There is authentication but no authorization. The rest of the lab fixes that.

---

## Part B — The RBAC Data Layer

### Task 1. Create the RBAC migrations

Run:

```bash
php artisan make:migration create_roles_table
php artisan make:migration create_permissions_table
php artisan make:migration create_permission_role_table
php artisan make:migration add_role_id_to_users_table
```

Open each generated file in `database/migrations/` (match by the descriptive part of the filename, the timestamp prefix will differ) and replace its entire contents:

**`..._create_roles_table.php`**

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};
```

**`..._create_permissions_table.php`**

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};
```

**`..._create_permission_role_table.php`**

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permission_role', function (Blueprint $table) {
            $table->id();
            $table->foreignId('permission_id')->constrained()->cascadeOnDelete();
            $table->foreignId('role_id')->constrained()->cascadeOnDelete();
            $table->unique(['permission_id', 'role_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permission_role');
    }
};
```

**`..._add_role_id_to_users_table.php`**

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('role_id')
                ->nullable()
                ->after('id')
                ->constrained()
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('role_id');
        });
    }
};
```

### Task 2. Create the Role and Permission models

Run:

```bash
php artisan make:model Role
php artisan make:model Permission
```

**Replace all of `app/Models/Role.php`:**

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Role extends Model
{
    protected $fillable = ['name', 'slug'];

    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
}
```

**Replace all of `app/Models/Permission.php`:**

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Permission extends Model
{
    protected $fillable = ['name', 'slug'];

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class);
    }
}
```

### Task 3. Add RBAC helpers to the User model

`hasPermission()` is the single source of truth that every Gate and Policy method will call.

**Replace all of `app/Models/User.php`:**

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
        ];
    }

    /* ----------------------------------------------------------
     | RBAC helpers
     * ---------------------------------------------------------- */

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }

    /**
     * Determine if the user's role has the given permission slug.
     */
    public function hasPermission(string $slug): bool
    {
        if ($this->role === null) {
            return false;
        }

        return $this->role->permissions->contains('slug', $slug);
    }

    /**
     * Determine if the user has the given role slug.
     */
    public function hasRole(string $slug): bool
    {
        return $this->role?->slug === $slug;
    }
}
```

### Task 4. Seed the roles, permissions, and assignments

Run:

```bash
php artisan make:seeder RbacSeeder
```

**Replace all of `database/seeders/RbacSeeder.php`:**

```php
<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;

class RbacSeeder extends Seeder
{
    public function run(): void
    {
        /* 1. Permissions ------------------------------------------------ */
        $permissions = [
            'can_create' => 'Create inventory entries',
            'can_update' => 'Update inventory entries',
            'can_view'   => 'View individual item details',
            'can_remove' => 'Remove inventory entries',
            'can_print'  => 'Generate reports for printing',
        ];

        foreach ($permissions as $slug => $name) {
            Permission::firstOrCreate(['slug' => $slug], ['name' => $name]);
        }

        /* 2. Roles and their permissions -------------------------------- */
        $roles = [
            'system-administrator' => [
                'name'        => 'System Administrator',
                // Bypasses all checks via Gate::before(); no rows needed.
                'permissions' => [],
            ],
            'receiving-clerk' => [
                'name'        => 'Inventory Receiving Clerk',
                'permissions' => ['can_create', 'can_update', 'can_view'],
            ],
            'inventory-manager' => [
                'name'        => 'Inventory Manager',
                'permissions' => ['can_view'],
            ],
            'inventory-supervisor' => [
                'name'        => 'Inventory Supervisor',
                'permissions' => ['can_view', 'can_remove'],
            ],
            'reports-officer' => [
                'name'        => 'Inventory Reports Officer',
                'permissions' => ['can_print'],
            ],
        ];

        foreach ($roles as $slug => $definition) {
            $role = Role::firstOrCreate(['slug' => $slug], ['name' => $definition['name']]);

            $ids = Permission::whereIn('slug', $definition['permissions'])->pluck('id');
            $role->permissions()->sync($ids);
        }

        /* 3. Assign roles to the seeded demo users ---------------------- */
        $assignments = [
            'admin@inventory.test'      => 'system-administrator',
            'clerk@inventory.test'      => 'receiving-clerk',
            'manager@inventory.test'    => 'inventory-manager',
            'supervisor@inventory.test' => 'inventory-supervisor',
            'reports@inventory.test'    => 'reports-officer',
        ];

        foreach ($assignments as $email => $roleSlug) {
            User::where('email', $email)->update([
                'role_id' => Role::where('slug', $roleSlug)->value('id'),
            ]);
        }
    }
}
```

Register the seeder — **replace all of `database/seeders/DatabaseSeeder.php`** (RbacSeeder must run last, since it assigns roles to already-seeded users):

```php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            InventoryItemSeeder::class,
            RbacSeeder::class,
        ]);
    }
}
```

Then run:

```bash
php artisan migrate
php artisan db:seed --class=RbacSeeder
```

---

## Part C — The Authorization Layer

### Task 5. Create the InventoryItemPolicy

Laravel 13 auto-discovers the policy because it follows the naming convention in `app/Policies`.

```bash
php artisan make:policy InventoryItemPolicy --model=InventoryItem
```

**Replace all of `app/Policies/InventoryItemPolicy.php`:**

```php
<?php

namespace App\Policies;

use App\Models\InventoryItem;
use App\Models\User;

class InventoryItemPolicy
{
    /**
     * Any authenticated user may view the inventory LISTING.
     * (No permission governs the listing; can_view covers item DETAILS only.)
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * View an individual inventory item's details.
     */
    public function view(User $user, InventoryItem $inventoryItem): bool
    {
        return $user->hasPermission('can_view');
    }

    /**
     * Create new inventory entries.
     */
    public function create(User $user): bool
    {
        return $user->hasPermission('can_create');
    }

    /**
     * Update existing inventory entries.
     */
    public function update(User $user, InventoryItem $inventoryItem): bool
    {
        return $user->hasPermission('can_update');
    }

    /**
     * Remove existing inventory entries.
     */
    public function delete(User $user, InventoryItem $inventoryItem): bool
    {
        return $user->hasPermission('can_remove');
    }
}
```

### Task 6. Register Gates and the super-admin bypass

Two things happen in `boot()`: (1) `Gate::before()` grants the System Administrator everything before any other check runs; (2) one Gate is defined dynamically per permission row, so `can_print` becomes usable in route middleware and Blade.

**Replace all of `app/Providers/AppServiceProvider.php`:**

```php
<?php

namespace App\Providers;

use App\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        /*
        | Super-admin bypass: runs BEFORE every Gate and Policy check.
        | Returning true grants; returning null falls through to the
        | normal Gate/Policy logic.
        */
        Gate::before(function (User $user, string $ability) {
            if ($user->hasRole('system-administrator')) {
                return true;
            }

            return null;
        });

        /*
        | Dynamic Gates: one Gate per permission row in the database
        | (can_create, can_update, can_view, can_remove, can_print).
        | The try/catch + hasTable guard keeps artisan commands working
        | before the RBAC migrations have run.
        */
        try {
            if (Schema::hasTable('permissions')) {
                Permission::pluck('slug')->each(function (string $slug) {
                    Gate::define($slug, fn (User $user) => $user->hasPermission($slug));
                });
            }
        } catch (\Throwable) {
            // Database not ready (e.g. during composer install / CI).
        }
    }
}
```

> **Important:** returning `null` from `Gate::before()` lets the check fall through to the normal Gate or Policy. Returning `false` there would deny everyone else everything.

---

## Part D — Enforcing Authorization

### Task 7. Protect the report route with middleware

The `can:can_print` middleware rejects unauthorized users with HTTP 403 before the controller even runs.

**Replace all of `routes/web.php`:**

```php
<?php

use App\Http\Controllers\InventoryItemController;
use App\Http\Controllers\ReportController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('inventory.index'));

Route::middleware('auth')->group(function () {
    // First line of defense: route middleware backed by the can_print Gate.
    Route::get('/reports/inventory', [ReportController::class, 'index'])
        ->middleware('can:can_print')
        ->name('reports.inventory');

    Route::resource('inventory', InventoryItemController::class)
        ->parameters(['inventory' => 'inventoryItem']);
});
```

### Task 8. Authorize inside the controllers

Route middleware alone is not enough — authorize again in the controller with `Gate::authorize()`, which throws an `AuthorizationException` (HTTP 403) on failure.

**Replace all of `app/Http/Controllers/InventoryItemController.php`:**

```php
<?php

namespace App\Http\Controllers;

use App\Models\InventoryItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class InventoryItemController extends Controller
{
    public function index()
    {
        Gate::authorize('viewAny', InventoryItem::class);

        $items = InventoryItem::orderBy('name')->paginate(10);

        return view('inventory.index', compact('items'));
    }

    public function create()
    {
        Gate::authorize('create', InventoryItem::class);

        return view('inventory.create');
    }

    public function store(Request $request)
    {
        Gate::authorize('create', InventoryItem::class);

        $validated = $request->validate([
            'name'        => ['required', 'string', 'max:255'],
            'sku'         => ['required', 'string', 'max:50', 'unique:inventory_items,sku'],
            'description' => ['nullable', 'string'],
            'quantity'    => ['required', 'integer', 'min:0'],
            'unit_price'  => ['required', 'numeric', 'min:0'],
        ]);

        InventoryItem::create($validated);

        return redirect()->route('inventory.index')
            ->with('status', 'Inventory item created successfully.');
    }

    public function show(InventoryItem $inventoryItem)
    {
        Gate::authorize('view', $inventoryItem);

        return view('inventory.show', compact('inventoryItem'));
    }

    public function edit(InventoryItem $inventoryItem)
    {
        Gate::authorize('update', $inventoryItem);

        return view('inventory.edit', compact('inventoryItem'));
    }

    public function update(Request $request, InventoryItem $inventoryItem)
    {
        Gate::authorize('update', $inventoryItem);

        $validated = $request->validate([
            'name'        => ['required', 'string', 'max:255'],
            'sku'         => ['required', 'string', 'max:50', 'unique:inventory_items,sku,' . $inventoryItem->id],
            'description' => ['nullable', 'string'],
            'quantity'    => ['required', 'integer', 'min:0'],
            'unit_price'  => ['required', 'numeric', 'min:0'],
        ]);

        $inventoryItem->update($validated);

        return redirect()->route('inventory.index')
            ->with('status', 'Inventory item updated successfully.');
    }

    public function destroy(InventoryItem $inventoryItem)
    {
        Gate::authorize('delete', $inventoryItem);

        $inventoryItem->delete();

        return redirect()->route('inventory.index')
            ->with('status', 'Inventory item removed.');
    }
}
```

**Replace all of `app/Http/Controllers/ReportController.php`:**

```php
<?php

namespace App\Http\Controllers;

use App\Models\InventoryItem;
use Illuminate\Support\Facades\Gate;

class ReportController extends Controller
{
    public function index()
    {
        Gate::authorize('can_print');

        $items = InventoryItem::orderBy('name')->get();

        $totalQuantity = $items->sum('quantity');
        $totalValue    = $items->sum(fn ($item) => $item->quantity * $item->unit_price);

        return view('reports.inventory', compact('items', 'totalQuantity', 'totalValue'));
    }
}
```

### Task 9. Hide unauthorized actions in Blade

`@can` with two arguments hits the Policy; with one argument it hits a Gate. **This is a usability layer only — the real protection is Tasks 7 and 8.**

**Replace all of `resources/views/layouts/app.blade.php`:**

```blade
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Inventory System')</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <header class="navbar">
        <div class="brand">Inventory System</div>
        <nav>
            <a href="{{ route('inventory.index') }}">Inventory</a>

            @can('can_print')
                <a href="{{ route('reports.inventory') }}">Print Report</a>
            @endcan

            <span class="user-label">
                {{ auth()->user()->name }} ({{ auth()->user()->role?->name ?? 'No Role' }})
            </span>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn-link">Logout</button>
            </form>
        </nav>
    </header>

    <main class="container">
        @if (session('status'))
            <div class="alert">{{ session('status') }}</div>
        @endif

        @yield('content')
    </main>
</body>
</html>
```

**Replace all of `resources/views/inventory/index.blade.php`:**

```blade
@extends('layouts.app')

@section('title', 'Inventory Listing')

@section('content')
    <div class="card">
        <div class="page-header">
            <h1>Inventory Listing</h1>

            @can('create', App\Models\InventoryItem::class)
                <a href="{{ route('inventory.create') }}" class="btn">+ Add Item</a>
            @endcan
        </div>

        <table>
            <thead>
                <tr>
                    <th>SKU</th>
                    <th>Name</th>
                    <th class="num">Quantity</th>
                    <th class="num">Unit Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($items as $item)
                    <tr>
                        <td>{{ $item->sku }}</td>
                        <td>{{ $item->name }}</td>
                        <td class="num">{{ $item->quantity }}</td>
                        <td class="num">{{ number_format($item->unit_price, 2) }}</td>
                        <td>
                            <div class="actions">
                                @can('view', $item)
                                    <a href="{{ route('inventory.show', $item) }}" class="btn btn-outline btn-sm">View</a>
                                @endcan

                                @can('update', $item)
                                    <a href="{{ route('inventory.edit', $item) }}" class="btn btn-outline btn-sm">Edit</a>
                                @endcan

                                @can('delete', $item)
                                    <form method="POST" action="{{ route('inventory.destroy', $item) }}"
                                          onsubmit="return confirm('Remove this item?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                    </form>
                                @endcan

                                @if (auth()->user()->cannot('view', $item) &&
                                     auth()->user()->cannot('update', $item) &&
                                     auth()->user()->cannot('delete', $item))
                                    <span class="user-label">&mdash;</span>
                                @endif
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5">No inventory items found.</td></tr>
                @endforelse
            </tbody>
        </table>

        <div class="pagination-wrap">
            {{ $items->links('pagination.default') }}
        </div>
    </div>
@endsection
```

---

## Part E — Testing and Verification

Log in as each demo account and verify every cell of this matrix. For hidden buttons, also test the raw URL (e.g. `/inventory/1`, `/inventory/1/edit`, `/reports/inventory`) — it must return **HTTP 403**, proving enforcement is server-side, not merely cosmetic.

| Action                      | Admin | Clerk | Manager | Supervisor | Reports |
|---|---|---|---|---|---|
| See inventory listing |         ✓ |    ✓ |       ✓ |        ✓ |        ✓ |
| View item details (show) |      ✓ |      ✓ |     ✓ |        ✓ |      403 |
| Add item (create/store) |       ✓ |     ✓ |     403 |      403 |      403 |
| Edit item (edit/update) |       ✓ |     ✓ |     403 |      403 |      403 |
| Remove item (destroy) |         ✓ |    403 |    403 |       ✓ |       403 |
| Generate printable report |      ✓ |   403 |   403 |       403 |       ✓ |

You can also verify from tinker:

```bash
php artisan tinker
```

```php
$clerk = App\Models\User::where('email', 'clerk@inventory.test')->first();
$item = App\Models\InventoryItem::first();
$clerk->can('update', $item);   // true
$clerk->can('delete', $item);   // false
$clerk->can('can_print');       // false
```

---

## Troubleshooting

- **A Gate/Policy change doesn't take effect** → run `php artisan optimize:clear` and reload (cached config/views are the usual culprit).
- **Need a clean slate on data** → `php artisan migrate:fresh --seed` rebuilds everything (all three seeders run in order).
- **403 for everyone including admin** → check that `Gate::before()` returns `null` (not `false`) for non-admins.
- **Registration page appears** → confirm `'features' => []` in `config/fortify.php`.

---

## Deliverables (from the lab PDF)

- Zipped project source code (**exclude** `vendor` and `node_modules`);
- Screenshots of the inventory listing while logged in as each of the five roles;
- Screenshot of one HTTP 403 page produced by a direct-URL attempt;
- Written answers to the five analysis questions (Section X of the PDF) — **write these yourself**, they're the graded thinking part.

### Grading rubric

| Criterion | Weight |
|---|---|
| RBAC schema: migrations, models, relationships, seeder correctness | 25% |
| Authorization layer: Policy methods, dynamic Gates, Gate::before() bypass | 25% |
| Enforcement: route middleware, controller authorization, Blade directives | 25% |
| Testing matrix fully verified (including direct-URL 403 checks) | 15% |
| Analysis questions | 10% |
